package com.jpmc.boot.service.classes;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmc.boot.bean.SeekerRequirement;

import com.jpmc.boot.interfaces.SeekerRepo;
import com.jpmc.boot.service.interfaces.SeekerRequirementServiceI;

@Component
public class SeekerRequirementService implements SeekerRequirementServiceI
{
	@Autowired
	private SeekerRepo seekerRepo;

	@Transactional
	@Override
	public List<SeekerRequirement> getAllReq() {
		// TODO Auto-generated method stub
		return seekerRepo.findAll();
		
	}
	
	@Transactional
	@Override
	public boolean deleteRequirement(int requirementId) 
	{
		seekerRepo.deleteById(requirementId);
		
		return true;
	}

	@Transactional
	@Override
	public boolean updateRequirement(String requirementId, int noOfDays, long minBudget, long maxBudget) 
	{
			
		SeekerRequirement reqUpdate=seekerRepo.findById(requirementId).get();
		reqUpdate.setNoofdays(noOfDays);
		reqUpdate.setMinBudget(minBudget);
		reqUpdate.setMaxBudget(maxBudget);
		return true;
		
	}

	@Transactional
	@Override
	public SeekerRequirement addRequirement(SeekerRequirement seekerRequirement) {
		
		seekerRequirement.setStatus("New"); //newaly added
		return seekerRepo.save(seekerRequirement);
	}

	@Transactional
	@Override
	public SeekerRequirement updateReq(SeekerRequirement seekerRequirement) 
	{
		return seekerRepo.save(seekerRequirement);
		
		
	}

	@Transactional
	@Override
	public boolean approveRequirement(int requirementId) {
		System.out.println("Status" + requirementId);
		SeekerRequirement trainingUp = seekerRepo.findByRequirementId(requirementId);
		trainingUp.setStatus("Approved");
		return true;
	}

	@Transactional
	@Override
	public boolean rejectRequirement(int requirementId) {
		System.out.println("Status" + requirementId);
		SeekerRequirement trainingUp = seekerRepo.findByRequirementId(requirementId);
		trainingUp.setStatus("Rejected");
		return true;
		
	}
	
	
	

	
}
