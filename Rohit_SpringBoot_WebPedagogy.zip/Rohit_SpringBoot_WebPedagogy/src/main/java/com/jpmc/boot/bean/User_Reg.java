package com.jpmc.boot.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_reg2")
public class User_Reg 
{
	@Id
	private String email;
	private String firstname;
	private String lastname;
	private String dob;
	private String companyname;
	private String phoneNo;
	private String password;
	private String role;
	private String street;
	private String area;
	private String	city;
	private String state;
	private String country;
	private String pancardNo; // only for provider
	private String gstNo;  		// only for provider
	private String subscription;		// only for provider
	private String provider_type;	// only for provider


	


	public User_Reg(String email, String firstname, String lastname, String dob, String companyname, String phoneNo,
			String password, String role, String street, String area, String city, String state, String country,
			String pancardNo, String gstNo, String subscription, String provider_type) {
		super();
		this.email = email;
		this.firstname = firstname;
		this.lastname = lastname;
		this.dob = dob;
		this.companyname = companyname;
		this.phoneNo = phoneNo;
		this.password = password;
		this.role = role;
		this.street = street;
		this.area = area;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pancardNo = pancardNo;
		this.gstNo = gstNo;
		this.subscription = subscription;
		this.provider_type = provider_type;
	}





	public String getEmail() {
		return email;
	}





	public void setEmail(String email) {
		this.email = email;
	}





	public String getFirstname() {
		return firstname;
	}





	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}





	public String getLastname() {
		return lastname;
	}





	public void setLastname(String lastname) {
		this.lastname = lastname;
	}





	public String getDob() {
		return dob;
	}





	public void setDob(String dob) {
		this.dob = dob;
	}





	public String getCompanyname() {
		return companyname;
	}





	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}





	public String getPhoneNo() {
		return phoneNo;
	}





	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}





	public String getPassword() {
		return password;
	}





	public void setPassword(String password) {
		this.password = password;
	}





	public String getRole() {
		return role;
	}





	public void setRole(String role) {
		this.role = role;
	}





	public String getStreet() {
		return street;
	}





	public void setStreet(String street) {
		this.street = street;
	}





	public String getArea() {
		return area;
	}





	public void setArea(String area) {
		this.area = area;
	}





	public String getCity() {
		return city;
	}





	public void setCity(String city) {
		this.city = city;
	}





	public String getState() {
		return state;
	}





	public void setState(String state) {
		this.state = state;
	}





	public String getCountry() {
		return country;
	}





	public void setCountry(String country) {
		this.country = country;
	}





	public String getPancardNo() {
		return pancardNo;
	}





	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}





	public String getGstNo() {
		return gstNo;
	}





	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}





	public String getSubscription() {
		return subscription;
	}





	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}





	public String getProvider_type() {
		return provider_type;
	}





	public void setProvider_type(String provider_type) {
		this.provider_type = provider_type;
	}





	public User_Reg() {
		super();
	}





	@Override
	public String toString() {
		return "User_Reg [email=" + email + ", firstname=" + firstname + ", lastname=" + lastname + ", dob=" + dob
				+ ", companyname=" + companyname + ", phoneNo=" + phoneNo + ", password=" + password + ", role=" + role
				+ ", street=" + street + ", area=" + area + ", city=" + city + ", state=" + state + ", country="
				+ country + ", pancardNo=" + pancardNo + ", gstNo=" + gstNo + ", subscription=" + subscription
				+ ", provider_type=" + provider_type + "]";
	}



}
