package com.jpmc.boot.service.interfaces;

import java.util.List;

import com.jpmc.boot.bean.SeekerRequirement;

public interface SeekerRequirementServiceI 
{
	public List<SeekerRequirement> getAllReq();
	
	public boolean deleteRequirement(int requirementId);
	
	public boolean updateRequirement(String requirementId,int noOfDays,long minBudget,long maxBudget);
	
	public SeekerRequirement addRequirement(SeekerRequirement seekerRequirement);
	
	public SeekerRequirement updateReq(SeekerRequirement seekerRequirement);
	
	public boolean approveRequirement(int requirementId);
	
	public boolean rejectRequirement(int requirementId);
	
}
