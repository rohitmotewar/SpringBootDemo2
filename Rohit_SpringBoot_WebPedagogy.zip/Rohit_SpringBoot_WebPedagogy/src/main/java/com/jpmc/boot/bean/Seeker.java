package com.jpmc.boot.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Seeker 
{
	@Id
	private String email;
	private String firstName;
	private String lastName;
	private String companyName;
	private String mobileNo;
	private String street;
	private String area;
	private String	city;
	private String state;
	private String country;
	private String password;
	private String role;
	
	
	//private List<SeekerRequirement> requirementList;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Seeker(String email, String firstName, String lastName, String companyName, String mobileNo, String street,
			String area, String city, String state, String country, String password, String role) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.companyName = companyName;
		this.mobileNo = mobileNo;
		this.street = street;
		this.area = area;
		this.city = city;
		this.state = state;
		this.country = country;
		this.password = password;
		this.role = role;
	}
	public Seeker() {
		super();
	}
	@Override
	public String toString() {
		return "Seeker [email=" + email + ", firstName=" + firstName + ", lastName=" + lastName + ", companyName="
				+ companyName + ", mobileNo=" + mobileNo + ", street=" + street + ", area=" + area + ", city=" + city
				+ ", state=" + state + ", country=" + country + ", password=" + password + ", role=" + role + "]";
	}
	
	
	
	
	
		
}
