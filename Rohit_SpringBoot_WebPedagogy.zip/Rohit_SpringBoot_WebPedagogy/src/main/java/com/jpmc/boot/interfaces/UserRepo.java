package com.jpmc.boot.interfaces;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jpmc.boot.bean.User_Reg;

@Repository
public interface UserRepo extends JpaRepository<User_Reg,String>
{
	

}
