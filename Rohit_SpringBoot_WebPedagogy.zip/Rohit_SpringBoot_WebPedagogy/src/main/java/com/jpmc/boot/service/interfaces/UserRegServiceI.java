package com.jpmc.boot.service.interfaces;

import java.util.List;

import com.jpmc.boot.bean.Admin;
import com.jpmc.boot.bean.Provider;
import com.jpmc.boot.bean.Seeker;
import com.jpmc.boot.bean.User_Reg;

public interface UserRegServiceI 
{
	
	
	public User_Reg addUser(User_Reg user);
	
	public List<User_Reg> getAllUser(); // Not required
	
	public List<Seeker> getAllSeeker(); //get all seekers
	
	public List<Provider> getAllProviderr(); //gt all providers
	
	public boolean deleteUser(String email);
	
	public User_Reg updateUser(User_Reg user);
	
	public Seeker addSeeker(Seeker seeker);
	
	public Provider addProvider(Provider provider);
	
	public Object validateUser(String email,String password,String role);
	
	public Seeker updateSeeker(Seeker seeker);
	
	public Provider updateProvider(Provider provider);
	
	public Admin updateAdmin(Admin admin);
	
	public boolean deleteSeeker(String email);
	
	public boolean deleteProvider(String email);
	

}
