package com.jpmc.boot.interfaces;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jpmc.boot.bean.SeekerRequirement;

@Repository
public interface SeekerRepo extends JpaRepository<SeekerRequirement,String>
{

	@Transactional
	@Modifying
	@Query("delete SeekerRequirement s  where s.requirementId=:requirementId")
	public void deleteById(int requirementId);

 public SeekerRequirement findByRequirementId(int requirementid);
	
 //public SeekerRequirement findByRequirementId(int requirementid);

}
