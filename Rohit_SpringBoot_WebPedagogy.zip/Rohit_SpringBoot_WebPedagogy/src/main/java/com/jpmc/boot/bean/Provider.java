package com.jpmc.boot.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Provider 
{
	@Id
	private String email;
	private String firstName;
	private String lastName;
	private String provider_type; // Company/Individual
	private String companyName;
	private String dateOfBirth;
	private String pancardNo;
	private String gstNo;
	private String subscription;
	private String role;
	private String password;
	private String phoneNo;
	private String street;
	private String area;
	private String	city;
	private String state;
	private String country;
	
	
	//private List<ProviderSkills> skillList;	
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	
	public String getProvider_type() {
		return provider_type;
	}
	public void setProvider_type(String provider_type) {
		this.provider_type = provider_type;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getGstNo() {
		return gstNo;
	}
	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}
	public String getSubscription() {
		return subscription;
	}
	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	
	
	
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Provider() {
		super();
	}
	public Provider(String email, String firstName, String lastName, String provider_type, String companyName,
			String dateOfBirth, String pancardNo, String gstNo, String subscription, String role, String password,
			String phoneNo, String street, String area, String city, String state, String country) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.provider_type = provider_type;
		this.companyName = companyName;
		this.dateOfBirth = dateOfBirth;
		this.pancardNo = pancardNo;
		this.gstNo = gstNo;
		this.subscription = subscription;
		this.role = role;
		this.password = password;
		this.phoneNo = phoneNo;
		this.street = street;
		this.area = area;
		this.city = city;
		this.state = state;
		this.country = country;
	}
	@Override
	public String toString() {
		return "Provider [email=" + email + ", firstName=" + firstName + ", lastName=" + lastName + ", provider_type="
				+ provider_type + ", companyName=" + companyName + ", dateOfBirth=" + dateOfBirth + ", pancardNo="
				+ pancardNo + ", gstNo=" + gstNo + ", subscription=" + subscription + ", role=" + role + ", password="
				+ password + ", phoneNo=" + phoneNo + ", street=" + street + ", area=" + area + ", city=" + city
				+ ", state=" + state + ", country=" + country + "]";
	}
	
	
	
	
	
	
	
	
	

}
