package com.jpmc.boot.service.classes;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmc.boot.bean.Admin;
import com.jpmc.boot.bean.Provider;
import com.jpmc.boot.bean.Seeker;
import com.jpmc.boot.bean.User_Reg;
import com.jpmc.boot.interfaces.AdminRepo;
import com.jpmc.boot.interfaces.ProviderRegRepo;
import com.jpmc.boot.interfaces.SeekerRegRepo;
import com.jpmc.boot.interfaces.UserRepo;
import com.jpmc.boot.service.interfaces.UserRegServiceI;

@Component
public class UserRegService implements UserRegServiceI
{
	
	@Autowired
	private UserRepo userRepo; 
	
	@Autowired
	private SeekerRegRepo seekerRepo;
	
	@Autowired
	private ProviderRegRepo providerRepo;
	
	@Autowired
	private AdminRepo adminRepo;
	

	@Transactional
	@Override
	public User_Reg addUser(User_Reg user) {
		
		return userRepo.save(user);
	}

	@Override
	public List<User_Reg> getAllUser() {
		
		return userRepo.findAll();
		 
	}
	
	
	@Transactional
	@Override
	public boolean deleteUser(String email) {
		
		userRepo.deleteById(email);
		return true;
	}

	@Transactional
	@Override
	public User_Reg updateUser(User_Reg user) {
		
		return userRepo.save(user);
		
	}

	@Transactional
	@Override
	public Seeker addSeeker(Seeker seeker) {


		return seekerRepo.save(seeker);
		
	}

	@Transactional
	@Override
	public Provider addProvider(Provider provider) {
		// TODO Auto-generated method stub
		return providerRepo.save(provider);
	}

	@Transactional
	@Override
	public Object validateUser(String email, String password, String role) 
	{
		if(role.equalsIgnoreCase("seeker"))
		{
			Seeker id=seekerRepo.findById(email).get();
			System.out.println(id);
			if(id!=null) 
			{
				if(id.getPassword().equals(password))
					return id;
			}
		}
		else if(role.equalsIgnoreCase("provider"))
		{
			Provider id=providerRepo.findById(email).get();
			System.out.println(id);
			if(id!=null)
			{
				if(id.getPassword().equals(password))
					return id;
				
			}
		}
		
		else if(role.equalsIgnoreCase("admin"))
		{
			Admin id=adminRepo.findById(email).get();
			System.out.println("Admin ID:" +id);
			if(id!=null)
			{
				if(id.getPassword().equals(password))
					return id;
				
			}
		}
		else
		{
			System.out.println("Invalid Details");
			return false;
		}
		return false;
		
		
	}

	@Override
	public List<Seeker> getAllSeeker() {
		// TODO Auto-generated method stub
		return seekerRepo.findAll();
	}

	@Override
	public List<Provider> getAllProviderr() {
		// TODO Auto-generated method stub
		return providerRepo.findAll();
	}

	@Transactional
	@Override
	public Seeker updateSeeker(Seeker seeker) {
		// TODO Auto-generated method stub
		return seekerRepo.save(seeker);
	}
	
	
	
	@Transactional
	@Override
	public Provider updateProvider(Provider provider) {
		// TODO Auto-generated method stub
		return providerRepo.save(provider);
	}

	@Transactional
	@Override
	public Admin updateAdmin(Admin admin) {
		
		return adminRepo.save(admin);
	}

	
	
	@Transactional
	@Override
	public boolean deleteSeeker(String email) {
		seekerRepo.deleteById(email);
		return true;
	}

	@Transactional
	@Override
	public boolean deleteProvider(String email) {
		providerRepo.deleteById(email);
		return true;
	}

	

	
	

}
