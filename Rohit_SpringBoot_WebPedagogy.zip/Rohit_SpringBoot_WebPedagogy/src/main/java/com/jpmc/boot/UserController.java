package com.jpmc.boot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jpmc.boot.bean.Admin;
import com.jpmc.boot.bean.Provider;
import com.jpmc.boot.bean.Seeker;
import com.jpmc.boot.bean.User_Reg;
import com.jpmc.boot.service.interfaces.UserRegServiceI;


@CrossOrigin(origins = "*", maxAge=3600)
@RestController
public class UserController 
{
	@Autowired
	private UserRegServiceI userService;
	
	Seeker seeker=new Seeker();
	Provider provider=new Provider();
	
	
	
	@RequestMapping(method=RequestMethod.GET, value="/getallusers")
	public List<User_Reg> getAllUser()
	{
		return userService.getAllUser();
	}
	
	
	
	@RequestMapping(method=RequestMethod.GET, value="/getallseeker")
	public List<Seeker> getallSeeker()
	{
		return userService.getAllSeeker();
		
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/getallprovider")
	public List<Provider> getallProvider()
	{
		return userService.getAllProviderr();
		
	}
	
	
	@RequestMapping(method=RequestMethod.POST, value="/adduser")
	public User_Reg addUser(@RequestBody User_Reg user)
	{
		if(user.getRole().equalsIgnoreCase("seeker"))
		{
			
			seeker.setEmail(user.getEmail());
			seeker.setFirstName(user.getFirstname());
			seeker.setLastName(user.getLastname());
			seeker.setMobileNo(user.getPhoneNo());
			seeker.setPassword(user.getPassword());
			seeker.setRole(user.getRole());
			seeker.setCompanyName(user.getCompanyname());
			seeker.setStreet(user.getStreet());
			seeker.setArea(user.getArea());
			seeker.setCity(user.getCity());
			seeker.setState(user.getState());
			seeker.setCountry(user.getCountry());	
						
			
			userService.addSeeker(seeker);
			
		}
		
		else if(user.getRole().equalsIgnoreCase("provider"))
		{
			provider.setEmail(user.getEmail());
			provider.setFirstName(user.getFirstname());
			provider.setLastName(user.getLastname());
			provider.setPhoneNo(user.getPhoneNo());
			provider.setPassword(user.getPassword());
			provider.setRole(user.getRole());
			provider.setStreet(user.getStreet());
			provider.setArea(user.getArea());
			provider.setCity(user.getCity());
			provider.setState(user.getState());
			provider.setCountry(user.getCountry());	
			provider.setDateOfBirth(user.getDob());
			provider.setProvider_type(user.getProvider_type());
			provider.setPancardNo(user.getPancardNo());
			provider.setGstNo(user.getGstNo());
			provider.setSubscription(user.getSubscription());
			
			userService.addProvider(provider);
			
		}
		return userService.addUser(user);
		
		
	}
	
	
	//@RequestMapping(method=RequestMethod.POST,value="/validateuser/email/{email}/password/{password}/role/{role}")
	
	@GetMapping("/validateuser/email/{email}/password/{password}/role/{role}")
	public Object validateUser(@PathVariable("email") String email,@PathVariable("password") String password,@PathVariable("role") String role ) 
	{
		System.out.println("email:"+email);
		Object obj= userService.validateUser(email, password, role);
		System.out.println(obj);
		return userService.validateUser(email, password, role);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/updateseeker")
	public Seeker updateSeeker(@RequestBody Seeker seeker)
	{
		return userService.updateSeeker(seeker);
		
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/updateprovider")
	public Provider updateProvider(@RequestBody Provider provider)
	{
		return userService.updateProvider(provider);
		
	}
	
	
	
	@RequestMapping(method=RequestMethod.POST, value="/updateadmin")
	public Admin updateAdmin(@RequestBody Admin admin)
	{
		return userService.updateAdmin(admin);
		
	}
	
	
	
	
	@RequestMapping(method=RequestMethod.POST, value="/deleteseeker/email/{email}")
	public boolean deleteSeeker(@PathVariable String email)
	{
		userService.deleteSeeker(email);
		return true;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/deleteprovider/email/{email}")
	public boolean deleteProvider(@PathVariable String email)
	{
		userService.deleteProvider(email);
		return true;
	}
	
	

}
