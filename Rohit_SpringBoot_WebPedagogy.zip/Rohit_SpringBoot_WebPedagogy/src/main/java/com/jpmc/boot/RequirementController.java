package com.jpmc.boot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.jpmc.boot.bean.SeekerRequirement;

import com.jpmc.boot.service.interfaces.SeekerRequirementServiceI;

@RestController
@CrossOrigin(origins = "*", maxAge=3600)
public class RequirementController 
{
	
	@Autowired
	//private BookRepo bookRepo;
	
	private SeekerRequirementServiceI seekerReqService;
	
	
	//@Autowired
	//private LimitConfg limitConfig;
	
	@GetMapping("/hello")
	public String sayHello()
	{
		return "Hi, you are in Web Pedagogy App";
		
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/getallrequirements")
	public List<SeekerRequirement> getAllReq()
	{
		return seekerReqService.getAllReq();
	}
	//@RequestMapping(method=RequestMethod.DELETE, value="/deleterequirement/requirementId/{requirementId}")
	@DeleteMapping("/deleterequirement/requirementId/{requirementId}")
	public boolean deleteRequirement(@PathVariable("requirementId") int requirementId)
	{
		
		return seekerReqService.deleteRequirement(requirementId);
		
	}
	
	@GetMapping(value="/updaterequirement/requirementId/{requirementId}/noOfDays/{noOfDays}/minBudget/{minBudget}/maxBudget/{maxBudget}")
	public boolean updateRequirement(@PathVariable("requirementId") String requirementId,@PathVariable("noOfDays") int noOfDays,@PathVariable("minBudget") long minBudget,@PathVariable("maxBudget") long maxBudget)
	{
		seekerReqService.updateRequirement(requirementId, noOfDays, minBudget, maxBudget);
		return true;
		
	}
	
	//OR
	
	@RequestMapping(method=RequestMethod.POST, value="/updateReq")
	public SeekerRequirement updateReq(@RequestBody SeekerRequirement seekerRequirement )
	{
		return seekerReqService.updateReq(seekerRequirement);
		
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/addrequirement")
	public SeekerRequirement addRequirement(@RequestBody SeekerRequirement seekerRequirement)
	{
		return seekerReqService.addRequirement(seekerRequirement);
		
	}
	
	//new methods
	
	@GetMapping("/approverequirement/requirementId/{requirementid}")
	public boolean approveRequirement(@PathVariable("requirementid") int requirementId)
			
	{
		System.out.println("inside value"+requirementId);
		return seekerReqService.approveRequirement(requirementId);
	}
	
	
	@GetMapping("/rejectrequirement/requirementId/{requirementid}")
	public boolean rejectRequirement(@PathVariable("requirementid") int requirementId)
			
	{
		System.out.println("inside value"+requirementId);
		return seekerReqService.rejectRequirement(requirementId);
	}
	

}
