package com.jpmc.boot.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="seekersrequirement")
public class SeekerRequirement 
{
	@Id	
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "requirement_Id")
	private int requirementId;
	private String module_Description;
	private int noofdays;
	private String startday;
	@Column(name = "min_Budget")
	private long minBudget;
	@Column(name = "max_Budget")
	private long maxBudget;
	private String location;
	private String training_Level;
	private String takeaways;
	private String status;
	
	
	//private String email--Foreign Key
	/*@OneToOne
	private User_Reg user;
*/
	
	
	public int getRequirementId() {
		return requirementId;
	}
	public void setRequirementId(int requirementId) {
		this.requirementId = requirementId;
	}
	public String getModule_Description() {
		return module_Description;
	}
	public void setModule_Description(String module_Description) {
		this.module_Description = module_Description;
	}
	public int getNoofdays() {
		return noofdays;
	}
	public void setNoofdays(int noofdays) {
		this.noofdays = noofdays;
	}
	public String getStartday() {
		return startday;
	}
	public void setStartday(String startday) {
		this.startday = startday;
	}
	public long getMinBudget() {
		return minBudget;
	}
	public void setMinBudget(long minBudget) {
		this.minBudget = minBudget;
	}
	public long getMaxBudget() {
		return maxBudget;
	}
	public void setMaxBudget(long maxBudget) {
		this.maxBudget = maxBudget;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTraining_Level() {
		return training_Level;
	}
	public void setTraining_Level(String training_Level) {
		this.training_Level = training_Level;
	}
	public String getTakeaways() {
		return takeaways;
	}
	public void setTakeaways(String takeaways) {
		this.takeaways = takeaways;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public SeekerRequirement(int requirementId, String module_Description, int noofdays, String startday,
			long minBudget, long maxBudget, String location, String training_Level, String takeaways, String status) {
		super();
		this.requirementId = requirementId;
		this.module_Description = module_Description;
		this.noofdays = noofdays;
		this.startday = startday;
		this.minBudget = minBudget;
		this.maxBudget = maxBudget;
		this.location = location;
		this.training_Level = training_Level;
		this.takeaways = takeaways;
		this.status = status;
	}
	public SeekerRequirement() {
		super();
	}
	@Override
	public String toString() {
		return "SeekerRequirement [requirementId=" + requirementId + ", module_Description=" + module_Description
				+ ", noofdays=" + noofdays + ", startday=" + startday + ", minBudget=" + minBudget + ", maxBudget="
				+ maxBudget + ", location=" + location + ", training_Level=" + training_Level + ", takeaways="
				+ takeaways + ", status=" + status + "]";
	}
	
	


/*	public SeekerRequirement(int requirementId, String module_Description, int noofdays, String startday,
			long minBudget, long maxBudget, String location, String training_Level, String takeaways, User_Reg user) {
		super();
		this.requirementId = requirementId;
		this.module_Description = module_Description;
		this.noofdays = noofdays;
		this.startday = startday;
		this.minBudget = minBudget;
		this.maxBudget = maxBudget;
		this.location = location;
		this.training_Level = training_Level;
		this.takeaways = takeaways;
		//this.user = user;
	}


	public SeekerRequirement() {
		super();
	}


	public int getRequirementId() {
		return requirementId;
	}


	public void setRequirementId(int requirementId) {
		this.requirementId = requirementId;
	}


	public String getModule_Description() {
		return module_Description;
	}


	public void setModule_Description(String module_Description) {
		this.module_Description = module_Description;
	}


	public int getNoofdays() {
		return noofdays;
	}


	public void setNoofdays(int noofdays) {
		this.noofdays = noofdays;
	}


	public String getStartday() {
		return startday;
	}


	public void setStartday(String startday) {
		this.startday = startday;
	}


	public long getMinBudget() {
		return minBudget;
	}


	public void setMinBudget(long minBudget) {
		this.minBudget = minBudget;
	}


	public long getMaxBudget() {
		return maxBudget;
	}


	public void setMaxBudget(long maxBudget) {
		this.maxBudget = maxBudget;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getTraining_Level() {
		return training_Level;
	}


	public void setTraining_Level(String training_Level) {
		this.training_Level = training_Level;
	}


	public String getTakeaways() {
		return takeaways;
	}


	public void setTakeaways(String takeaways) {
		this.takeaways = takeaways;
	}


	public User_Reg getUser() {
		return user;
	}


	public void setUser(User_Reg user) {
		this.user = user;
	}


	@Override
	public String toString() {
		return "SeekerRequirement [requirementId=" + requirementId + ", module_Description=" + module_Description
				+ ", noofdays=" + noofdays + ", startday=" + startday + ", minBudget=" + minBudget + ", maxBudget="
				+ maxBudget + ", location=" + location + ", training_Level=" + training_Level + ", takeaways="
				+ takeaways + "]";
	}*/
	
	
	
	
	

}
